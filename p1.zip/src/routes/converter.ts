import { Router } from "express";
import { convertCurrency } from "../utils/currencyApi";
import RecordModel from "../models/record";

const router = Router();

router.post("/", async (req, res) => {
  const { from, to, amount } = req.body;
  try {
    const result = await convertCurrency(from, to, amount);
    const record = new RecordModel({ from, to, amount, result });
    await record.save();
    res.json({ result });
  } catch (e) {
    res.status(500).json({ error: "Conversion failed" });
  }
});

export default router;
