import { Router } from "express";
import RecordModel from "../models/record";

const router = Router();

router.get("/", async (_req, res) => {
  const records = await RecordModel.find().sort({ date: -1 });
  res.json(records);
});

export default router;
