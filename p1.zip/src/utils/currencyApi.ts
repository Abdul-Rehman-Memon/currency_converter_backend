import axios from "axios";
import dotenv from "dotenv";

dotenv.config();
const API_KEY = process.env.API_KEY;

export async function convertCurrency(
  from: string,
  to: string,
  amount: number
) {
  const url = `https://api.freecurrencyapi.com/v1/latest?base_currency=${from}&currencies=${to}`;
  const resp = await axios.get(url, { headers: { apikey: API_KEY! } });
  const rate = resp.data.data[to];
  return rate * amount;
}
