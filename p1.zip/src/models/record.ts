import { Schema, model } from "mongoose";

interface Record {
  from: string;
  to: string;
  amount: number;
  result: number;
  date: Date;
}

const recordSchema = new Schema<Record>({
  from: String,
  to: String,
  amount: Number,
  result: Number,
  date: { type: Date, default: Date.now },
});

export default model<Record>("Record", recordSchema);
